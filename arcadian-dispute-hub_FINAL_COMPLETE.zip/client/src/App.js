import React from 'react';
import { Routes, Route } from 'react-router-dom';
import LetterPreview from './pages/LetterPreview';
import BatchLetterGenerator from './pages/BatchLetterGenerator';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Upload from './pages/Upload';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/upload" element={<Upload />} />
      <Route path="/letter" element={<LetterPreview />} />
    <Route path="/batch" element={<BatchLetterGenerator />} />
    <Route path="/login" element={<Login />} />
  <Route path="/register" element={<Register />} />
  </Routes>
  );
}

export default App;