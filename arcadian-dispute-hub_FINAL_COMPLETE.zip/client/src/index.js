import React from 'react';
import { Routes, Route } from 'react-router-dom';
import LetterPreview from './pages/LetterPreview';
import BatchLetterGenerator from './pages/BatchLetterGenerator';
import Dashboard from './pages/Dashboard';
import Upload from './pages/Upload';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/upload" element={<Upload />} />
      <Route path="/letter" element={<LetterPreview />} />
    <Route path="/batch" element={<BatchLetterGenerator />} />
  </Routes>
    </AuthProvider>
);
}

export default App;