import React, { useState } from 'react';
import axios from 'axios';

export default function BatchLetterGenerator() {
  const [issues, setIssues] = useState([{ type: '', line: '' }]);
  const [letters, setLetters] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleInputChange = (index, field, value) => {
    const newIssues = [...issues];
    newIssues[index][field] = value;
    setIssues(newIssues);
  };

  const addIssue = () => {
    setIssues([...issues, { type: '', line: '' }]);
  };

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const generated = await Promise.all(
        issues.map(issue => axios.post('/api/generate', { issue }))
      );
      setLetters(generated.map(res => res.data.letter));
    } catch (err) {
      console.error('Batch generation error:', err);
    }
    setLoading(false);
  };

  const handleDownloadAll = async () => {
    try {
      const res = await axios.post('/api/generate/pdf/batch', { issues }, {
        responseType: 'blob',
      });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'dispute-letters-batch.pdf');
      document.body.appendChild(link);
      link.click();
    } catch (err) {
      console.error('Batch PDF download error:', err);
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Batch Dispute Letter Generator</h2>
      {issues.map((issue, index) => (
        <div key={index} className="mb-4 border-b pb-2">
          <input
            type="text"
            placeholder="Issue Type"
            value={issue.type}
            onChange={(e) => handleInputChange(index, 'type', e.target.value)}
            className="border p-2 mb-2 block w-full"
          />
          <input
            type="text"
            placeholder="Credit Report Line"
            value={issue.line}
            onChange={(e) => handleInputChange(index, 'line', e.target.value)}
            className="border p-2 block w-full"
          />
        </div>
      ))}
      <button onClick={addIssue} className="bg-gray-600 text-white px-4 py-2 mr-2">Add Another</button>
      <button onClick={handleGenerate} disabled={loading} className="bg-blue-500 text-white px-4 py-2 mr-2">
        {loading ? 'Generating...' : 'Generate Letters'}
      </button>
      <button onClick={handleDownloadAll} className="bg-green-600 text-white px-4 py-2">
        Download All as PDF
      </button>

      {letters.length > 0 && (
        <div className="mt-6 p-4 border bg-gray-100 whitespace-pre-wrap">
          <h3 className="font-semibold mb-2">Generated Letters:</h3>
          {letters.map((letter, i) => (
            <div key={i} className="mb-4">
              <pre>{letter}</pre>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
