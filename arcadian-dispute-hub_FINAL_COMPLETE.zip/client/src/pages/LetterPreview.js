import React, { useState } from 'react';
import axios from 'axios';

export default function LetterPreview() {
  const [issue, setIssue] = useState({ type: '', line: '' });
  const [letter, setLetter] = useState('');
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const res = await axios.post('/api/generate', { issue });
      setLetter(res.data.letter);
    } catch (err) {
      console.error('Error generating letter:', err);
    }
    setLoading(false);
  };

  const handleDownload = async () => {
    try {
      const res = await axios.post('/api/generate/pdf', { issue }, {
        responseType: 'blob',
      });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'dispute-letter.pdf');
      document.body.appendChild(link);
      link.click();
    } catch (err) {
      console.error('Error downloading PDF:', err);
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Dispute Letter Generator</h2>
      <input
        type="text"
        placeholder="Issue Type (e.g., Collection Account)"
        value={issue.type}
        onChange={(e) => setIssue({ ...issue, type: e.target.value })}
        className="border p-2 mb-2 block w-full"
      />
      <input
        type="text"
        placeholder="Credit Report Line"
        value={issue.line}
        onChange={(e) => setIssue({ ...issue, line: e.target.value })}
        className="border p-2 mb-4 block w-full"
      />
      <button
        onClick={handleGenerate}
        disabled={loading}
        className="bg-blue-500 text-white px-4 py-2 mr-2"
      >
        {loading ? 'Generating...' : 'Generate Letter'}
      </button>
      <button
        onClick={handleDownload}
        disabled={!letter}
        className="bg-green-600 text-white px-4 py-2"
      >
        Download PDF
      </button>

      {letter && (
        <div className="mt-6 p-4 border bg-gray-100 whitespace-pre-wrap">
          <h3 className="font-semibold mb-2">Letter Preview:</h3>
          <pre>{letter}</pre>
        </div>
      )}
    </div>
  );
}
