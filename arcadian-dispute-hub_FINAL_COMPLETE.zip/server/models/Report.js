const mongoose = require('mongoose');

const ReportSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  uploadedFileName: String,
  extractedText: String,
  issues: [
    {
      type: { type: String },
      line: String
    }
  ],
  createdAt: { type: Date, default: Date.now },
  flagged: { type: Boolean, default: false }
});

module.exports = mongoose.model('Report', ReportSchema);
