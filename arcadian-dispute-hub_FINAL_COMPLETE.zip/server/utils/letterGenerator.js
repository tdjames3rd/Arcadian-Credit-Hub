
function generateDisputeLetter(issue) {
  const baseTemplate = `
Dear [Credit Bureau Name],

I am writing to dispute the following item on my credit report. This item is inaccurate and incomplete, and I am requesting its removal in accordance with the Fair Credit Reporting Act (FCRA).

Item: ${issue.line}
Issue Type: ${issue.type}

Under Section 609 and Section 611 of the FCRA, I request that you verify this information and provide the original source and signed documentation, or promptly delete the item from my report.

Sincerely,
[Your Full Name]
[Address]
[City, State ZIP]
[Date]
  `;

  return baseTemplate.trim();
}

module.exports = { generateDisputeLetter };
