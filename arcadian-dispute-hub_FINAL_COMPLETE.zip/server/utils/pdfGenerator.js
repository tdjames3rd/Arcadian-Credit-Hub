
const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');

function exportLetterAsPDF(letterText, filename = 'dispute-letter.pdf') {
  const doc = new PDFDocument();
  const filePath = path.join(__dirname, '../pdfs', filename);

  return new Promise((resolve, reject) => {
    const stream = fs.createWriteStream(filePath);
    doc.pipe(stream);
    doc.font('Times-Roman').fontSize(12).text(letterText, {
      width: 480,
      align: 'left'
    });
    doc.end();

    stream.on('finish', () => resolve(filePath));
    stream.on('error', reject);
  });
}

module.exports = { exportLetterAsPDF };
