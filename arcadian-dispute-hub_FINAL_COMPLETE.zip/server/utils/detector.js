
// Basic discrepancy detection logic for extracted credit report text
function detectDiscrepancies(ocrText) {
  const issues = [];
  const lines = ocrText.split('\n');

  lines.forEach((line, index) => {
    const lowerLine = line.toLowerCase();

    // Sample rule: detect collections
    if (lowerLine.includes('collection') || lowerLine.includes('collections agency')) {
      issues.push({
        type: 'Collection Account',
        line: line.trim(),
        index
      });
    }

    // Sample rule: detect charge-offs
    if (lowerLine.includes('charge off')) {
      issues.push({
        type: 'Charge-Off',
        line: line.trim(),
        index
      });
    }

    // Sample rule: detect late payments
    if (lowerLine.includes('30 days late') || lowerLine.includes('60 days late') || lowerLine.includes('late payment')) {
      issues.push({
        type: 'Late Payment',
        line: line.trim(),
        index
      });
    }

    // Sample rule: detect inquiries
    if (lowerLine.includes('hard inquiry') || lowerLine.includes('credit inquiry')) {
      issues.push({
        type: 'Inquiry',
        line: line.trim(),
        index
      });
    }

    // Add more detection rules here
  });

  return issues;
}

module.exports = { detectDiscrepancies };
