const Tesseract = require('tesseract.js');
const fs = require('fs');
const path = require('path');

async function parseCreditReport(filePath) {
  try {
    const { data: { text } } = await Tesseract.recognize(
      filePath,
      'eng',
      {
        logger: m => console.log(m)
      }
    );
    return text;
  } catch (error) {
    console.error('OCR Error:', error);
    throw new Error('Failed to parse credit report');
  }
}

module.exports = { parseCreditReport };
