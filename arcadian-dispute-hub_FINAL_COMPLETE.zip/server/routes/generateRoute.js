const authMiddleware = require('../middleware/auth');
const express = require('express');
const { exportLetterAsPDF } = require('../utils/pdfGenerator');
const { generateDisputeLetter } = require('../utils/letterGenerator');
const fs = require('fs');

const router = express.Router();

router.post('/pdf', authMiddleware, async (req, res) => {
  const { issue } = req.body;

  if (!issue || !issue.line || !issue.type) {
    return res.status(400).send({ message: "Missing issue data" });
  }

  const letter = generateDisputeLetter(issue);
  try {
    const filePath = await exportLetterAsPDF(letter);
    const file = fs.readFileSync(filePath);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename=dispute-letter.pdf');
    res.send(file);
  } catch (error) {
    res.status(500).send({ message: "Failed to generate PDF", error: error.message });
  }
});

module.exports = router;

router.post('/pdf/batch', authMiddleware, async (req, res) => {
  const { issues } = req.body;

  if (!Array.isArray(issues)) {
    return res.status(400).send({ message: "Missing or invalid issues array" });
  }

  const doc = new (require('pdfkit'))();
  const path = require('path');
  const fs = require('fs');
  const tempPath = path.join(__dirname, '../pdfs', 'batch-dispute-letters.pdf');
  const stream = fs.createWriteStream(tempPath);
  doc.pipe(stream);

  try {
    for (const issue of issues) {
      const letter = require('../utils/letterGenerator').generateDisputeLetter(issue);
      doc.addPage().font('Times-Roman').fontSize(12).text(letter, { width: 480, align: 'left' });
    }
    doc.end();

    stream.on('finish', () => {
      const file = fs.readFileSync(tempPath);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', 'attachment; filename=dispute-letters-batch.pdf');
      res.send(file);
    });
  } catch (error) {
    res.status(500).send({ message: "Failed to generate batch PDF", error: error.message });
  }
});
