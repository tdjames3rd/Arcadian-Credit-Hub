const authMiddleware = require('../middleware/auth');
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { parseCreditReport } = require('../utils/ocr');
const { detectDiscrepancies } = require('../utils/detector');

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.post('/', authMiddleware, upload.single('creditReport'), async (req, res) => {
  if (!req.file) return res.status(400).send("No file uploaded.");

  const filePath = path.resolve(__dirname, '../uploads', req.file.filename);

  try {
    const extractedText = await parseCreditReport(filePath);
    const issues = detectDiscrepancies(extractedText);
    res.send({
      message: "File uploaded and parsed successfully",
      extractedText,
      issues
    });
  } catch (error) {
    res.status(500).send({ message: "OCR parsing failed", error: error.message });
  }
});

module.exports = router;