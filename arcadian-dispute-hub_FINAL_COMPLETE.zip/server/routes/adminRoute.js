const express = require('express');
const User = require('../models/User');
const Report = require('../models/Report');
const authMiddleware = require('../middleware/auth');

const router = express.Router();

// Admin-only middleware
function adminOnly(req, res, next) {
  const adminEmails = process.env.ADMIN_EMAILS?.split(',') || [];
  if (!adminEmails.includes(req.user.email)) {
    return res.status(403).json({ message: 'Admin access only' });
  }
  next();
}

router.get('/users', authMiddleware, adminOnly, async (req, res) => {
  try {
    const users = await User.find().select('-passwordHash');
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch users' });
  }
});

router.get('/reports', authMiddleware, adminOnly, async (req, res) => {
  try {
    const reports = await Report.find().populate('userId', 'email');
    res.json(reports);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch reports' });
  }
});

module.exports = router;


// Delete a report by ID (admin only)
router.delete('/report/:id', authMiddleware, adminOnly, async (req, res) => {
  try {
    const deleted = await Report.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: 'Report not found' });
    res.json({ message: 'Report deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete report' });
  }
});

// Flag a report by ID (admin only)
router.patch('/report/:id/flag', authMiddleware, adminOnly, async (req, res) => {
  try {
    const report = await Report.findById(req.params.id);
    if (!report) return res.status(404).json({ message: 'Report not found' });

    report.flagged = true;
    await report.save();
    res.json({ message: 'Report flagged' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to flag report' });
  }
});
