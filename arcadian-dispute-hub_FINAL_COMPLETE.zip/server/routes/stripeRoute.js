const express = require('express');
const Stripe = require('stripe');
const router = express.Router();

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

router.post('/create-checkout-session', async (req, res) => {
  const { priceId } = req.body;

  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      success_url: process.env.CLIENT_URL + '/success',
      cancel_url: process.env.CLIENT_URL + '/cancel',
    });

    res.json({ url: session.url });
  } catch (error) {
    res.status(500).json({ message: 'Stripe session creation failed', error: error.message });
  }
});

module.exports = router;
